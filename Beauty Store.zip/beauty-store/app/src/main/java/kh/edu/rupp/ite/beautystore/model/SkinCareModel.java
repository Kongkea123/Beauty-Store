package kh.edu.rupp.ite.beautystore.model;

public class SkinCareModel {
    private String name;

    public SkinCareModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
