package kh.edu.rupp.ite.beautystore.model;

public class Color {
    private String hex_value;
    private String colour_name;
}
